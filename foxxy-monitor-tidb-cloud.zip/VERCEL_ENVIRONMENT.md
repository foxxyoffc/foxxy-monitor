# Environment Variables untuk Vercel

Tambahkan variabel berikut melalui **Vercel → Project → Settings → Environment Variables**. Pilih lingkungan **Production** dan, bila diperlukan, **Preview**. Berkas `.env.example` hanya merupakan template: jangan diunggah sebagai `.env` dengan nilai nyata.

| Variabel | Status | Nilai yang diisi di Vercel |
| --- | --- | --- |
| `DATABASE_URL` | Wajib | Connection string MySQL/TiDB produksi dari penyedia database Anda. Aktifkan SSL bila penyedia mewajibkannya. |
| `JWT_SECRET` | Wajib | Secret acak baru yang panjang. Gunakan password manager atau generator secret; jangan memakai nilai contoh. |
| `GOOGLE_CLIENT_ID` | Wajib jika memakai Google Login | **Web application Client ID** dari Google Cloud OAuth. |
| `VITE_GOOGLE_CLIENT_ID` | Wajib jika memakai Google Login | Nilai yang **sama persis** dengan `GOOGLE_CLIENT_ID`. Karena diawali `VITE_`, nilai ini tersedia di browser dan memang bukan secret. |
| `VITE_APP_ID` | Opsional | Hanya bila Anda meneruskan OAuth bawaan pada rute `/api/oauth/callback`. |
| `OAUTH_SERVER_URL` | Opsional | URL server OAuth bawaan yang terkait dengan `VITE_APP_ID`. |
| `VITE_OAUTH_PORTAL_URL` | Opsional | URL portal OAuth bawaan untuk browser. |
| `OWNER_OPEN_ID` | Opsional | Hanya bila Owner awal dibuat melalui OAuth bawaan; tidak diperlukan untuk bootstrap Owner dengan username/password. |

## Langkah pengisian

1. Buka Vercel dan pilih proyek Foxxy Monitor.
2. Masuk ke **Settings → Environment Variables**.
3. Tambahkan setiap nama variabel di atas beserta nilai produksinya.
4. Simpan perubahan, lalu lakukan redeploy agar nilai `VITE_GOOGLE_CLIENT_ID` ikut dimasukkan ke build frontend.
5. Jika Google Login dipakai, buka Google Cloud Console dan tambahkan domain Vercel produksi pada **Authorized JavaScript origins**.

## Cara paling mudah bila memakai TiDB Cloud

Foxxy Monitor versi terbaru dapat membaca parameter TiDB satu per satu, sehingga Anda tidak perlu merakit `DATABASE_URL` secara manual dari HP. Di Vercel, isi nilai berikut persis dari dialog **Connect** TiDB Cloud:

```text
TIDB_ENABLE_SSL=true
TIDB_HOST=<HOST>
TIDB_PORT=4000
TIDB_USER=<USERNAME>
TIDB_PASSWORD=<PASSWORD>
TIDB_DATABASE=sys
```

Anda dapat mengisi parameter TiDB di atas *atau* satu `DATABASE_URL`. Bila `DATABASE_URL` ada, nilainya diprioritaskan. Untuk TiDB Cloud Starter/Essential pada public endpoint, TLS wajib digunakan; aplikasi mengaktifkan TLS otomatis untuk host `tidbcloud.com`, sedangkan `TIDB_ENABLE_SSL=true` menjadi pengaman tambahan. [1] [2]

> `DATABASE_URL` dan `JWT_SECRET` adalah rahasia produksi. Simpan hanya di Vercel atau password manager, jangan pernah di GitHub, ZIP sumber publik, atau chat.

## Catatan Google Login

Gunakan Client ID jenis **Web application** dan tambahkan domain produksi, contohnya `https://nama-proyek.vercel.app`, ke **Authorized JavaScript origins**. Implementasi Foxxy Monitor menggunakan Google Identity token di browser, sehingga tidak membutuhkan **Authorized Redirect URI** untuk alur Google Login ini.

## Referensi

[1]: https://docs.pingcap.com/tidbcloud/secure-connections-to-serverless-clusters/ "TiDB Cloud TLS connections"
[2]: https://docs.pingcap.com/developer/dev-guide-sample-application-nodejs-mysql2/ "TiDB with node-mysql2"
