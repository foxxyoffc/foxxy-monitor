# Deployment Vercel — Foxxy Monitor

Foxxy Monitor dibangun dengan React/Vite di frontend dan Express/tRPC di backend. Berkas `server.ts` mengekspor aplikasi Express sehingga Vercel dapat menjalankannya sebagai Function, sedangkan `build:vercel` menyalin hasil Vite ke direktori `public/` untuk distribusi aset dan rute SPA.

Sebelum deploy, tambahkan environment variables produksi berikut di **Vercel Project Settings → Environment Variables**. Nilai harus sama dengan nilai yang dipakai saat pengembangan, kecuali URL aplikasi yang memang berubah di produksi.

| Variabel | Keterangan |
| --- | --- |
| `DATABASE_URL` | String koneksi database MySQL/TiDB produksi. |
| `JWT_SECRET` | Secret acak yang kuat untuk cookie sesi bawaan. |
| `GOOGLE_CLIENT_ID` | OAuth Client ID Web application Google untuk verifikasi ID token. |
| `VITE_GOOGLE_CLIENT_ID` | Client ID Google yang sama untuk Google Identity di browser. |
| `OAUTH_SERVER_URL`, `VITE_OAUTH_PORTAL_URL`, `VITE_APP_ID` | Diperlukan bila tetap memakai integrasi OAuth bawaan. |

Di Google Cloud Console, tambahkan URL produksi Anda pada **Authorized JavaScript origins**. Untuk alur Google Identity yang digunakan Foxxy Monitor, tidak diperlukan **Authorized Redirect URI**. Redirect URL hanya dibutuhkan bila Anda di kemudian hari mengganti alur ini menjadi OAuth authorization-code berbasis redirect.

Gunakan `pnpm build:vercel` untuk memverifikasi build sebelum menghubungkan repository ke Vercel. Setelah deployment berhasil, perbarui Authorized JavaScript origin Google jika domain berubah.
