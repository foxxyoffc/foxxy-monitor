# Setup Foxxy Monitor dari HP

Dokumen ini memandu setup database dan environment Vercel tanpa laptop. Gunakan browser ponsel, lalu simpan seluruh password dan URL database di password manager. Jangan mengirim nilai rahasia ke chat atau menyimpannya di GitHub.

## Pilihan database gratis

| Pilihan | Cocok untuk | Batas gratis utama | Catatan penting |
| --- | --- | --- | --- |
| **Aiven for MySQL** | Rekomendasi paling sederhana untuk Foxxy Monitor karena memakai MySQL standar | 1 GB storage, 1 GB RAM, 1 CPU, tanpa kartu kredit | Service dapat dimatikan setelah periode tidak aktif; dibuat untuk proyek kecil/MVP, bukan trafik tinggi. [1] |
| **TiDB Cloud Starter** | Alternatif MySQL-compatible dengan kuota penyimpanan lebih besar | 5 GiB row storage, 5 GiB columnar storage, dan 50 juta RU/bulan pada kuota gratis | Jika kuota habis, koneksi baru dapat ditolak sampai kuota bulan berikutnya atau limit dinaikkan. [2] [3] |

## Rekomendasi: Aiven for MySQL

1. Dari HP, buka [Aiven Free MySQL](https://aiven.io/free-mysql-database) lalu pilih **Get building** atau langsung buka [halaman pendaftaran](https://console.aiven.io/signup?campaign=mysql_free_tier).
2. Daftar menggunakan akun Google/GitHub atau email, lalu pilih **Create Service** dan pilih **MySQL**.
3. Pilih region yang dekat dengan pengguna aplikasi. Paket gratis Aiven tidak membutuhkan kartu kredit. [1]
4. Setelah database aktif, buka halaman service lalu cari menu **Connection information** atau **Connect**.
5. Salin informasi host, port, nama database, username, dan password. Buat `DATABASE_URL` dengan pola berikut:

```text
mysql://USERNAME:PASSWORD@HOST:PORT/DATABASE?ssl={"rejectUnauthorized":true}
```

> Jika password memuat karakter seperti `@`, `:`, `/`, atau `#`, gunakan password yang dapat di-URL-encode atau URL-encode karakter tersebut sebelum memasukkannya ke `DATABASE_URL`.

## Alternatif: TiDB Cloud Starter

1. Dari HP, buka [TiDB Cloud Starter](https://tidbcloud.com/free-trial).
2. Buat instance **Starter**, lalu buka halaman instance dan tekan **Connect** untuk mengambil host, port, username berawalan prefix, dan password. [2]
3. Gunakan data yang ditampilkan untuk membentuk connection string MySQL. TiDB Cloud Starter membutuhkan koneksi TLS dan biasanya memakai port `4000`. [2]

## Membuat `JWT_SECRET` dari HP

1. Buka [Bitwarden Password Generator](https://bitwarden.com/password-generator/) di browser HP, atau gunakan generator password di password manager yang Anda percayai.
2. Pilih **Password**, panjang minimal **48 karakter**, dengan huruf besar, huruf kecil, angka, dan simbol.
3. Tekan **Copy**, lalu tempelkan hasilnya langsung sebagai nilai `JWT_SECRET` di Vercel.
4. Simpan satu salinan di password manager. Jangan pernah memposting nilai ini, karena menggantinya akan membuat sesi pengguna perlu login ulang.

## Memasukkan ke Vercel dari HP

1. Buka dashboard [Vercel](https://vercel.com/dashboard) di Chrome/Safari HP, lalu pilih proyek Foxxy Monitor.
2. Buka **Settings → Environment Variables**.
3. Tambahkan `DATABASE_URL`, lalu tempelkan URL dari Aiven atau TiDB.
4. Tambahkan `JWT_SECRET`, lalu tempelkan password acak yang baru dibuat.
5. Tambahkan `GOOGLE_CLIENT_ID` dan `VITE_GOOGLE_CLIENT_ID` dengan nilai Client ID Google yang sama bila ingin mengaktifkan Google Login.
6. Pilih environment **Production**, tekan **Save**, lalu buka tab **Deployments** dan tekan **Redeploy** pada deployment terakhir.

### Cara paling mudah bila memakai TiDB Cloud

Daripada merakit `DATABASE_URL`, masukkan setiap nilai dari dialog **Connect** TiDB sebagai environment terpisah berikut. Foxxy Monitor versi TiDB akan menyusunnya dengan aman dan mengaktifkan TLS.

```text
TIDB_ENABLE_SSL=true
TIDB_HOST=<HOST>
TIDB_PORT=4000
TIDB_USER=<USERNAME>
TIDB_PASSWORD=<PASSWORD>
TIDB_DATABASE=sys
```

## Ringkasan nilai minimum

```text
DATABASE_URL=mysql://...
JWT_SECRET=<secret-acak-minimal-48-karakter>
GOOGLE_CLIENT_ID=<opsional-bila-google-login-dipakai>
VITE_GOOGLE_CLIENT_ID=<nilai-yang-sama>
```

## Referensi

[1]: https://aiven.io/free-mysql-database "Aiven Free MySQL"
[2]: https://docs.pingcap.com/tidbcloud/select-cluster-tier/ "TiDB Cloud plan dan koneksi"
[3]: https://www.pingcap.com/tidb-cloud-starter-pricing-details/ "TiDB Cloud Starter free quota"
