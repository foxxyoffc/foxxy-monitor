# Foxxy Monitor — Daftar Periksa Deployment Vercel

Dokumen ini digunakan bersama `VERCEL.md` saat memindahkan Foxxy Monitor ke Vercel. Proyek menggunakan frontend React/Vite, backend Express/tRPC, dan database MySQL atau TiDB.

## 1. Siapkan sumber kode

Ekstrak arsip sumber, lalu instal dependensi dengan `pnpm install`. Jangan memasukkan file `.env` atau kredensial ke repository. Berkas `vercel.json`, `server.ts`, dan skrip `build:vercel` sudah disertakan.

## 2. Uji build lokal

Jalankan perintah berikut sebelum mengunggah proyek:

```bash
pnpm test
pnpm check
pnpm build:vercel
```

## 3. Buat proyek Vercel

Masuk ke Vercel, pilih **Add New → Project**, lalu impor repository GitHub atau unggah direktori proyek. Vercel akan membaca `vercel.json` dan menggunakan skrip build yang tersedia.

## 4. Atur environment variables produksi

Tambahkan seluruh nilai berikut pada **Project Settings → Environment Variables** untuk Production, Preview, dan Development jika diperlukan.

| Variabel | Kegunaan |
| --- | --- |
| `DATABASE_URL` | Koneksi database MySQL/TiDB produksi dengan SSL bila disediakan penyedia database. |
| `JWT_SECRET` | Secret acak yang panjang dan kuat untuk keamanan cookie sesi. |
| `GOOGLE_CLIENT_ID` | OAuth Client ID Web Google untuk validasi token Google. |
| `VITE_GOOGLE_CLIENT_ID` | Nilai Client ID Google yang sama untuk Google Identity di browser. |
| `OAUTH_SERVER_URL` | URL layanan OAuth bawaan apabila integrasi tersebut tetap dipakai. |
| `VITE_OAUTH_PORTAL_URL` | URL portal OAuth bawaan di browser. |
| `VITE_APP_ID` | ID aplikasi OAuth bawaan. |

> Jangan memasukkan `DATABASE_URL`, `JWT_SECRET`, atau secret lain ke kode sumber maupun GitHub.

## 5. Konfigurasi Google Login

Di Google Cloud Console, tambahkan domain Vercel produksi ke **Authorized JavaScript origins**, misalnya `https://foxxy-monitor.vercel.app` atau domain kustom Anda. Implementasi saat ini memakai Google Identity berbasis token di browser, sehingga **Authorized Redirect URI tidak diperlukan**.

## 6. Deploy dan verifikasi

Klik **Deploy** di Vercel. Setelah berhasil, buka URL produksi dan lakukan verifikasi berikut:

- Login Owner menggunakan username/password serta akun Google yang didaftarkan.
- Tambahkan satu admin dan pastikan pembatasan satu perangkat bekerja.
- Cek dashboard, chart, chat, tabungan, kontrol blacklist, serta reset data Owner.
- Isi ulang **Authorized JavaScript origin** Google bila domain produksi berubah.
- Isi URL **Kopi untuk Owner** dari kontrol cepat Owner setelah masuk.

## 7. Publikasi

Setelah pemeriksaan selesai, klik tombol **Publish** pada antarmuka pengelolaan proyek untuk hosting bawaan, atau gunakan deployment Vercel yang sudah disiapkan di atas. Untuk domain sendiri, tambahkan domain melalui pengaturan Vercel dan ulangi konfigurasi origin Google.
